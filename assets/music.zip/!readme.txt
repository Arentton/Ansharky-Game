Crystalline Horizons.m4a - Start Menu Theme
Hypnotic Void Texture.m4a - Start Game Theme (on the start)
Void Echoes.mp3 - Danger Zone / Unknown Thing theme
Luminous Stardust.m4a - Landing on the Moon theme
